package neu.coe.project;

import neu.coe.project.cloudapp.Controllers.LoginController;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class LoginControllerTest {
    @Test
    public void testCheckPassword() {
        LoginControllerTest tester = new LoginControllerTest(); // MyClass is tested
       LoginController login= new LoginController();
       // assert statements
        assertTrue(login.checkPassword("gronk","$2a$17$idweww2syRAQ.aKNaz4FcuUDXaBIV4UWEXvLCyVFxIk8WWDXE1aUG"));
        assertTrue(login.checkPassword("Edelman","$2a$17$KNoxVGMYHgIGsHAjTCQJa..InSp2o4NL.gYb95Fi65v3/V88Ua2nS"));
    }
   /* @Test
    public void testHashPassword() {
        LoginControllerTest tester = new LoginControllerTest(); // MyClass is tested
        LoginController login= new LoginController();
        // assert statements
        assertEquals(login.hashPassword("gronk"),"$2a$17$Aj5gHoDtUp0pZEpA1QhjwOIuFOCtIxcDx/3ih5c0U.f6m1LuuQ5aC");
        assertEquals(login.hashPassword("Edelman"),"$2a$17$KNoxVGMYHgIGsHAjTCQJa..InSp2o4NL.gYb95Fi65v3/V88Ua2nS");
    }*/

}
