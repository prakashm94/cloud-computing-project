package neu.coe.project.cloudapp.Repository;

import neu.coe.project.cloudapp.Model.UserData;
import org.springframework.data.repository.CrudRepository;

public interface UserDataRepository extends CrudRepository<UserData, Long> {

}
