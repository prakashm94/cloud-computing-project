package neu.coe.project.cloudapp.Repository;

import neu.coe.project.cloudapp.Model.TransactionData;
import neu.coe.project.cloudapp.Model.UserData;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface TransactionDataRepository extends CrudRepository<TransactionData, String> {
    //TransactionData findById(Long transactionId);
}
